$(document).ready(function() {

  $('a:not(.page-logo)').attr('target', '_blank');
  
    const $body = $('body');
    $body.on('click', '#play-pause', function() {
      const el = $(this);
      const video = $('#intro-video')[0];
      if (video.paused) {
        video.play();
        el.removeClass('paused');
        el.find('.play-pause-text').text('Pause Video');
        el.attr('aria-label', 'Pause Video');
      } else {
        video.pause();
        el.addClass('paused');
        el.find('.play-pause-text').text('Play Video');
        el.attr('aria-label', 'Play Video');
      }
    });

    $body.on('click', '#menu-button', function(){
      const el = $(this);
      const menu = $('#menu-window');

      if(menu.hasClass('menu-open')){
        menu.removeClass('menu-open visible opacity-100').addClass('invisible opacity-0');
      } else {
        menu.removeClass('invisible opacity-0').addClass('menu-open visible opacity-100');
      }
    });


    $body.on('click', '#menu-close-button', function(){
        const menu = $('#menu-window');
        menu.removeClass('menu-open visible opacity-100').addClass('invisible opacity-0');
    });



    $(document).keyup(function(e){
      if (e.keyCode == 27) { 
        $('#menu-close-button').trigger('click');
      }
  });

    $body.on('click', 'ul[aria-labelledby="navHeading"] > li > button.ui-link', function(){
      const el = $(this);
      const list = el.closest('li').find('ul');
      el.closest('li').siblings().find('button.ui-link').attr('aria-expanded', 'false');
      el.closest('li').siblings().find('button.ui-link .a-icon--chevron-down400').css('transform', 'rotate(0deg)');
      el.closest('li').siblings().find('ul').addClass('hidden');
      if(el.attr('aria-expanded') === 'false'){
        el.attr('aria-expanded', 'true');
        list.removeClass('hidden');
        el.find('.a-icon--chevron-down400').css('transform', 'rotate(180deg)');
      } else {
        list.addClass('hidden');
        el.find('.a-icon--chevron-down400').css('transform', 'rotate(0deg)');
        el.attr('aria-expanded', 'false');
        
      }
      
    });

    $body.on('click', '.accordion-item > h3 > button', function(){
      const el = $(this);
      const accordion = el.closest('h3').next('div');
      if(el.attr('aria-expanded') === 'false'){
        el.attr('aria-expanded', 'true');
        accordion.css('height', 'fit-content');
        el.find('.a-icon--plus400').replaceWith('<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="a-icon--minus400 a-icon--text a-icon--no-align ml-auto flex-none" style="width:1em;height:1em;" data-new="" aria-hidden="true" data-v-22ee7e7c=""><rect data-v-22ee7e7c="" fill="currentColor" x="2" y="7.3" width="12" height="1.4"></rect></svg>')
      } else {
        el.attr('aria-expanded', 'false');
        accordion.css('height', '0');
        el.find('.a-icon--minus400').replaceWith('<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="a-icon--plus400 a-icon--text a-icon--no-align ml-auto flex-none" style="width:1em;height:1em;" data-new="" aria-hidden="true" data-v-22ee7e7c=""><polygon fill="currentColor" points="14 7.31 8.69 7.31 8.69 2 7.31 2 7.31 7.31 2 7.31 2 8.69 7.31 8.69 7.31 14 8.69 14 8.69 8.69 14 8.69 14 7.31" data-v-22ee7e7c=""></polygon></svg>')
      }
    });
    
  });
  