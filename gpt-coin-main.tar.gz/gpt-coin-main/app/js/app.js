$(document).ready(function() {
  
    var $body = $('body');
    
    function setWrapperHeight() {
      if (window.innerWidth < 800) {
        var contentHeight = $('.main-wrapper').outerHeight();
        $('.site-wrapper').css('height', 'calc(' + contentHeight + 'px + 133px)');
      }
    }
    
    setWrapperHeight();
    $(window).on('resize', function() {
      setWrapperHeight();
    });

    $body.on('click', '#play-pause', function() {
      var el = $(this);
      var video = $('#intro-video')[0];
      if (video.paused) {
        video.play();
        el.removeClass('paused');
        el.find('.play-pause-text').text('Pause Video');
        el.attr('aria-label', 'Pause Video');
      } else {
        video.pause();
        el.addClass('paused');
        el.find('.play-pause-text').text('Play Video');
        el.attr('aria-label', 'Play Video');
      }
    });

    $body.on('click', '#menu-button', function(){
      var el = $(this);
      var menu = $('#menu-window');

      if(menu.hasClass('menu-open')){
        menu.removeClass('menu-open visible opacity-100').addClass('invisible opacity-0');
      } else {
        menu.removeClass('invisible opacity-0').addClass('menu-open visible opacity-100');
      }
    });


    $body.on('click', '#menu-close-button', function(){
        var menu = $('#menu-window');
        menu.removeClass('menu-open visible opacity-100').addClass('invisible opacity-0');
    });



    $(document).keyup(function(e){
      if (e.keyCode == 27) { 
        $('#menu-close-button').trigger('click');
      }
  });

    $body.on('click', 'ul[aria-labelledby="navHeading"] > li > button.ui-link', function(){
      var el = $(this);
      var list = el.closest('li').find('ul');
      el.closest('li').siblings().find('button.ui-link').attr('aria-expanded', 'false');
      el.closest('li').siblings().find('button.ui-link .a-icon--chevron-down400').css('transform', 'rotate(0deg)');
      el.closest('li').siblings().find('ul').addClass('hidden');
      if(el.attr('aria-expanded') === 'false'){
        el.attr('aria-expanded', 'true');
        list.removeClass('hidden');
        el.find('.a-icon--chevron-down400').css('transform', 'rotate(180deg)');
      } else {
        list.addClass('hidden');
        el.find('.a-icon--chevron-down400').css('transform', 'rotate(0deg)');
        el.attr('aria-expanded', 'false');
        
      }
      
    });

    $body.on('click', '.accordion-item > h3 > button', function(){
      var el = $(this);
      var accordion = el.closest('h3').next('div');
      if(el.attr('aria-expanded') === 'false'){
        el.attr('aria-expanded', 'true');
        accordion.css('height', 'fit-content');
        el.find('.a-icon--plus400').replaceWith('<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="a-icon--minus400 a-icon--text a-icon--no-align ml-auto flex-none" style="width:1em;height:1em;" data-new="" aria-hidden="true" data-v-22ee7e7c=""><rect data-v-22ee7e7c="" fill="currentColor" x="2" y="7.3" width="12" height="1.4"></rect></svg>')
      } else {
        el.attr('aria-expanded', 'false');
        accordion.css('height', '0');
        el.find('.a-icon--minus400').replaceWith('<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" class="a-icon--plus400 a-icon--text a-icon--no-align ml-auto flex-none" style="width:1em;height:1em;" data-new="" aria-hidden="true" data-v-22ee7e7c=""><polygon fill="currentColor" points="14 7.31 8.69 7.31 8.69 2 7.31 2 7.31 7.31 2 7.31 2 8.69 7.31 8.69 7.31 14 8.69 14 8.69 8.69 14 8.69 14 7.31" data-v-22ee7e7c=""></polygon></svg>')
      }
    });

    $body.on('input', '.swap__amount-input', function() {
      var el = $(this);
      var el_sell = $('.swap__block-sell .swap__amount-input');
      var textWidth = getTextWidth(el.val(), el.css('font'));
      var inputWidth = el.width() + 60;
      var button = el.closest('.swap__amount').find('.swap__max-button')
      if (textWidth == inputWidth - 60 || textWidth > inputWidth - 60) {
            button.css({
              'left': '0',
              'right': 'auto'
            });
           
          } else if (textWidth == 0){
            button.css({
              'left': 'auto',
              'right': '15px'
            });
          } else {
            button.css({
              'right': textWidth + 'px',
              'left': 'auto'
            });
        }
        console.log(el_sell);
        console.log(el_sell.val());
        if(el_sell.val() >= 20){
          el_sell.closest('.swap__block').removeClass('_insufficient_funds');
          $('.swap__button').removeClass('_disabled').find('p').text('Buy GPT COIN');
          
        } else {
          el_sell.closest('.swap__block').addClass('_insufficient_funds');
          $('.swap__button').addClass('_disabled').find('p').text('Insufficient funds');
        }
    });
    
    
    function getTextWidth(text, font) {
      var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
      var context = canvas.getContext("2d");
      context.font = font;
      var metrics = context.measureText(text);
      return metrics.width;
    }

    $body.on('click', '#swap__select-button', function(){
      $('.currency-select').removeClass('_hidden');
      $('.swap__wrapper').addClass('_hidden');
    });


    $body.on('click', '.currency-select__exit', function(){
      $('.currency-select').addClass('_hidden');
      $('.swap__wrapper').removeClass('_hidden');
    });

    $body.on('click', '.currency-select__button', function(){
      var el = $(this);
      var select = $('#swap__select-button');
      $('.currency-select').addClass('_hidden');
      $('.swap__wrapper').removeClass('_hidden');
      

      select.find('.swap__currency-icon').attr('data-icon', el.data('currency'));
      select.find('.swap__currency-text').text(el.data('currency'));
    });
    
    
    
    $body.on('click', '.popup__open-button', function(){
      const popupId = $('#' + $(this).attr('rel'));
      $(popupId).addClass('popup--show');
      $('html').addClass('lock');
  });
  
    $body.on('click', '.popup__overlay, .popup__close', function () {
        $(this).closest('.popup').removeClass('popup--show');
        if(!$('.popup').hasClass('popup--show')){
            $('html').removeClass('lock');
        };
    });

    $(document).keyup(function(e){
      if (e.keyCode == 27) { 
          $('.popup').removeClass('popup--show');
          if(!$('.popup').hasClass('popup--show')){
              $('html').removeClass('lock');
          };
      }
  });

  
  function showAlert(selector) {
    const $alert = $(selector);
    $alert.addClass('show');
    setTimeout(function() {
      $alert.removeClass('show');
    }, 5000);
  }
  
  $body.on('click', '.alert__close', function() {
    $(this).closest('.alert').removeClass('show');
  });
  
  $body.on('click', '.recent-transactions', function() {
    showAlert('#alert-success');
  });
  
  $body.on('click', '.clear-all', function() {
    showAlert('#alert-fail');
  });

  $(function() {
    var address = $('.contract__link').attr('title');
    var shortened = address.substr(0, 7) + '...' + address.substr(-5);
    $('.contract__link:not(#connect-wallet .contract__link)').text(shortened);
    $('.contract__copy').on('click', function() {
      var tempInput = $('<input>');
      $('body').append(tempInput);
      tempInput.val(address).select();
      document.execCommand('copy');
      tempInput.remove();
      var copiedMessage = $('<span class="copied-message">Copied!</span>');
      $(this).append(copiedMessage);
      setTimeout(function() {
        copiedMessage.remove();
      }, 5000);

    });
  });
  

  $(function() {
    $('.contract-link-shorted').each(function() {
      var parentWidth = Math.floor($(this).closest('.contract-link-shorted-container').width() * 0.42);
      var fontSize =  parseInt($(this).css('font-size'));
      var averageCharWidth = fontSize * 0.6;
      var maxChars = Math.floor(parentWidth / averageCharWidth);
      var address = $(this).text();
      var shortlink = address.substr(0, maxChars) + '...' + address.substr(-maxChars);
      $(this).text(shortlink);
    });
  });
  });

  //TIMER

  function startTimer(duration, display) {
    var timer = duration, days, hours, minutes, seconds;
    var intervalId = setInterval(function () {
      days = parseInt(timer / 86400, 10);
      hours = parseInt((timer - days * 86400) / 3600, 10);
      minutes = parseInt((timer - days * 86400 - hours * 3600) / 60, 10);
      seconds = parseInt(timer % 60, 10);
  
      days = days < 10 ? "0" + days : days;
      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;
  
      display.find('.days').text(days);
      display.find('.hours').text(hours);
      display.find('.minutes').text(minutes);
      display.find('.seconds').text(seconds);
  
      if (--timer < 0) {
        clearInterval(intervalId);
        $('.withdraw').removeClass('_grey').addClass('_cream');
      }
    }, 1000);
  }
  
  $(function () {
    var startDate = new Date("2023-05-10 13:47:00"); 
    var durationInSeconds = 90 * 24 * 60 * 60; 
    var duration = durationInSeconds - Math.floor((new Date() - startDate) / 1000);
    var display = $('#countdown');
    startTimer(duration, display);
  });
  
  